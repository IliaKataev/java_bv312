/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.servlet;

import com.example.dao.ManufacturerDAO;
import com.example.model.Manufacturer;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author artgl
 */
//@WebServlet("/manufacturers")
public class ManufacturerServlet extends HttpServlet {
    private ManufacturerDAO dao = new ManufacturerDAO();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String idParam = req.getParameter("id");
        try {
            if (idParam != null) {
                int id = Integer.parseInt(idParam);
                Manufacturer m = dao.findById(id);
                req.setAttribute("manufacturer", m);
                req.getRequestDispatcher("/manufacturer-details.jsp").forward(req, resp);
            } else {
                List<Manufacturer> list = dao.findAll();
                req.setAttribute("manufacturers", list);
                req.getRequestDispatcher("/manufacturers.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
