/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.dao;

import com.example.model.Manufacturer;
import com.example.util.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;


/**
 *
 * @author artgl
 */
public class ManufacturerDAO {
    
    private Manufacturer map(ResultSet rs) throws SQLException {
        Manufacturer m = new Manufacturer();
                m.setId(rs.getInt("id"));
                m.setName(rs.getString("name"));
                m.setCountry(rs.getString("country"));
                m.setLogoUrl(rs.getString("logo_url"));
                m.setEmployeesCount(rs.getInt("employees_count"));
                m.setDescription(rs.getString("description"));
                return m;
    }
    
    public List<Manufacturer> findAll() throws Exception{
        List<Manufacturer> list = new ArrayList<>();
        DataSource ds = DBUtil.getDataSource();
        String sql = "SELECT id, name, country, logo_url, employees_count, description FROM manufacturer ORDER BY name";
        try(Connection conn = ds.getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery()){
            while(rs.next()){
                Manufacturer m = new Manufacturer();
                m.setId(rs.getInt("id"));
                m.setName(rs.getString("name"));
                m.setCountry(rs.getString("country"));
                m.setLogoUrl(rs.getString("logo_url"));
                m.setEmployeesCount(rs.getInt("employees_count"));
                m.setDescription(rs.getString("description"));
                list.add(m);
            }
        }
        return list;
    }
    
    public List<Manufacturer> findFiltered(String country, Integer minEmp) throws Exception{
        DataSource ds = DBUtil.getDataSource();
        List<Manufacturer> list = new ArrayList<>();
        
        String sql = "SELECT * FROM manufacturer WHERE 1=1";
        
        if(country != null && !country.isEmpty())
            sql += " AND country ILIKE ?";
        if(minEmp !=null)
            sql += " AND employees_count >= ?";
        
        try(Connection conn = ds.getConnection();
            PreparedStatement st = conn.prepareStatement(sql);){
            
            /////////////////////////////////////////////
            
            ResultSet rs = st.executeQuery();
            while(rs.next())
                list.add(map(rs));
            
        }
        return list;
    }
    
    
    public Manufacturer findById(int id) throws Exception{
        DataSource ds = DBUtil.getDataSource();
        String sql = "SELECT * FROM manufacturer WHERE id = ?";
        try(Connection conn = ds.getConnection();
            PreparedStatement st = conn.prepareStatement(sql);){
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            return rs.next() ? map(rs) : null;
        }
    }
    
    //save
    
    
    //update
    
    public void delete(int id) throws Exception{
        try(Connection c = DBUtil.getDataSource().getConnection();
                PreparedStatement st =
                        c.prepareStatement("DELETE FROM manufacturer where id=?")) {
                    st.setInt(1, id);
                    st.executeUpdate();
            
        }
    }
}
