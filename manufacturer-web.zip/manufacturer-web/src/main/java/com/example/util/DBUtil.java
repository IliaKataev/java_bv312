/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.util;
import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 *
 * @author artgl
 */
public class DBUtil {
    private static DataSource dataSource;
    
    public static DataSource getDataSource() throws Exception{
        if(dataSource == null){
            Context ctx = new InitialContext();
            dataSource = (DataSource) ctx.lookup("java:comp/env/laptopdb");
        }
        return dataSource;
    }
}
