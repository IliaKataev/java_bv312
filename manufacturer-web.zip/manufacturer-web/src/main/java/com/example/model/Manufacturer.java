/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.model;

/**
 *
 * @author artgl
 */

// JavaBean = POJO (Plain Old Java Object) + get/set

public class Manufacturer {
    private int id;
    private String name;
    private String country;
    private String logoUrl;
    int employeesCount;
    private String description;
    
    public Manufacturer(){}
    public Manufacturer(int id, String name, String country, String logoUrl, int employeesCount, String description){
        this.id = id; this.name = name;
        this.country = country; this.logoUrl = logoUrl;
        this.employeesCount = employeesCount; this.description = description;
    }
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    public String getLogoUrl() { return logoUrl; }
    public void setLogoUrl(String logoUrl) { this.logoUrl = logoUrl; }
    public int getEmployeesCount() { return employeesCount; }
    public void setEmployeesCount(int employeesCount) { this.employeesCount = employeesCount; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
}